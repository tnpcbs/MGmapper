#!/usr/bin/perl
use strict;
use Parallel::ChildManager;

# Demonstrates the use of results writeback to the parent.
# This only works when the child is spawned from the parents code.

my $cm = new ChildManager(3,0.3);
$cm->set_start_type('IPC');

# Calculates several factorials in parallel
for (my $i = 0; $i <= 10; $i++) {
   my $pid = $cm->start;
   next if $pid;
   # Child only code - calculates factorial
   my $fac = 1;
   my $no = $i;
   while ($no > 1) {
      $fac *= $no;
      $no--; }
   $cm->return_result(\$fac);
   # Child NEVER returns after delivering the result, it exits.
}

# Parent - if you were in doubt
$cm->wait_all_children;
my @results = $cm->get_all;

print "Factorials\n";
for (my $i = 0; $i <= $#results; $i++) {
   print "$i =>  ${$results[$i]}\n"; }

