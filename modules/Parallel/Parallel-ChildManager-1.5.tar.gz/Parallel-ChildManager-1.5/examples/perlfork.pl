#!/usr/bin/perl

use ChildManager;

$cm = new  ChildManager(3);
print "MASTER $$\n";
for($i= 1; $i<=10; $i++) {
   $tab[$i] = $cm->start;
   unless ($tab[$i]) {
      print "Child $$\n";
      for ($j=1; $j < 100000; $j++) {
         @arr = split(' ', 'nd dfkgj hdflkg hdflkgh dflkhg dflkg dfl kg'); }
      exit; }
}

