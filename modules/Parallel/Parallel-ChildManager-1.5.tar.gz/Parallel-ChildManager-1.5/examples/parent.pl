#!/usr/bin/perl

use Parallel::ChildManager;

print "Running 10 processes, 3 at a time.\n";
print "Every process has 18 seconds to finish.\n";

$cm = new ChildManager(3,0.3);

for ($i = 1; $i < 11; $i++) {
   $cm->start("./child.pl $i"); }

$cm->wait_all_children;

print "Bang - and all are dead\n";
