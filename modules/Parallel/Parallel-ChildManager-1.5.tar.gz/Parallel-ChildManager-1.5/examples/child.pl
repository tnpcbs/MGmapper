#!/usr/bin/perl

$SIG{'TERM'} = \&killed;

$max = int(rand(50) + 1);
print "Starting child: $ARGV[0] (job load: $max)\n";

# You might have to fiddle with the multiplication value
# in order for some children to reach the time limit (or the other way)
$max *= 50;

$sum = 0;
for ($i = 1; $i < $max; $i++) {
   for ($j = 1; $j < 5000; $j++) {
      $sum += sqrt($i*$j); }}
      
print "Child $ARGV[0] is finished.\n";


sub killed {
   print "Child $ARGV[0] was killed.\n";
   exit;
}
